import { DataTable } from './components/data-table/DataTable';

function App() {
  return (
    <div className="App">
      <header />
      <DataTable />
    </div>
  );
}

export default App;
